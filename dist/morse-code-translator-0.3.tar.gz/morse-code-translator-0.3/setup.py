from setuptools import setup

setup(
    name='morse-code-translator',
    version='0.3',
    scripts=['morse-code-translator']
)
